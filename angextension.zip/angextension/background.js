let color = '#4688f1';

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ color });
  console.clear();
  console.log('Active.');
});