let ang = document.getElementById("ang");

ang.addEventListener("click", async () => {
	chrome.tabs.create({
      url: 'https://angsteachingtemple.github.io'
    })
})
